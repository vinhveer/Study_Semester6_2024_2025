#include <bits/stdc++.h>
using namespace std;

void InitArray(vector<int>& perArr, int perNum)
{
    for (int i = 1; i <= perNum; i++) perArr.push_back(i);
}

bool Generate(vector<int>& perArr, int perNum)
{
    int i = perNum - 2;

    while (i >= 0 && perArr[i] >= perArr[i + 1]) i--;

    if (i < 0) return true;

    int j = perNum - 1;
    while (perArr[j] < perArr[i]) j--;
    
    swap(perArr[i], perArr[j]);
    reverse(perArr.begin() + i + 1, perArr.end());

    return false;
}

int main()
{
    int perNum;
    cin >> perNum;

    vector<int> perArr;
    InitArray(perArr, perNum);

    do
    {
        for (int x : perArr)
            cout << x << " ";
        
        cout << endl;
    } while (!Generate(perArr, perNum));

    return 0;
}
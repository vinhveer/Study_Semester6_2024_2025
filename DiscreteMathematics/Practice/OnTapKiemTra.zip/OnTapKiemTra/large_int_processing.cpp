#include <iostream>
#include <string>

using namespace std;

string Add(string number1, string number2)
{
    cout << number1.length();
    return "";
}

int main()
{
    Add("100", "200");
    return 0;
}
